// module.exports = {
//   HOST: "localhost",
//   PORT: "3306",
//   USER: "root",
//   PASSWORD: "Avinash@123",
//   DB: "darto",
//   dialect: "mysql",
//   pool: {
//     max: 5,
//     min: 0,
//     acquire: 30000,
//     idle: 10000,
//   },
// };
module.exports = {
  HOST: "31.220.52.245",
  //HOST: "localhost",
  PORT: "3306",
  USER: "darto_darto",
  PASSWORD: "fAu#Gg@OlH096!m%",
//   PASSWORD: "",
  DB: "darto_darto",
  dialect: "mysql",
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000,
  },
};

